#!/usr/bin/env bash
set -e
while [[ "$#" -gt 0 ]]; do
    case $1 in
        -kh|--kogni-home) KH="$2"; shift ;;
        -d|--docker) FOR_DOCKER=1 ;;
        -mh| --mysql-host) MH="$2"; shift;;
        -mu| --mysql-username) MU="$2"; shift;;
        -mpwd| --mysql-password) MPWD="$2"; shift;;
        -h|--help) printf "### Kogni Startup Script ###\n\nPass '-kh' or '--kogni-home' which should be same as what you have selected for installing Kogni \n\nAdd flag '-d' or '--docker' if you are running this script inside a container\n\nExample: './start_kogni.sh -kh /opt/kogni'\n\nExample: './start_kogni.sh -kh /opt/kogni -d\n"; exit 0 ;;
        *) echo "Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done

if [ -z ${KH+x} ];
  then
    printf "Kogni Home (-kh or --kogni-home) should be passed\n\nuse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MH+x} ];
  then
    printf "Mysql host (-mh or --mysql-host) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MU+x} ];
  then
    printf "Mysql username (-mu or --shared-access-signature) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MPWD+x} ];
  then
    printf "Mysql password (-mpwd  or --mysql-password) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ "$FOR_DOCKER" = 1 ];
  then
    SYSTEMCTL=systemctl.py
  else
    SYSTEMCTL=systemctl
fi

function method_break() {
    echo "================================================="
    echo ""
    echo ""
    sleep 3
    echo "================================================="
}

function install_mysql() {
    echo "============Installing Mysql============"
    cd $KOGNI_HOME
    sudo yum update
    sudo wget http://dev.mysql.com/get/mysql80-community-release-el7-3.noarch.rpm
    sudo rpm -Uvh mysql80-community-release-el7-3.noarch.rpm
    sudo yum-config-manager --disable mysql80-community
    sudo yum-config-manager --enable mysql57-community
    sudo yum module disable mysql
    sudo yum install mysql-community-server
    sudo rm -f mysql80-community-release-el7-3.noarch.rpm
    sudo $SYSTEMCTL start mysqld
    version=$(mysql --version|awk '{ print $5 }'|awk -F\, '{ print $1 }'| cut -c1-1)
    if [[ "$version" = "5" ]];
    then
      temp_password=$(grep 'temporary password' /var/log/mysqld.log | awk '{print $NF}')
    else
      temp_password=$(grep 'temporary password' /var/log/mysql/mysqld.log | awk '{print $NF}')
    fi
    echo $temp_password
    #REMOVING validate password plugin.
    echo "alter table"
    mysql -h $MH -u $MU --password="$temp_password" -e "ALTER USER $MU@'localhost' IDENTIFIED BY '$temp_password'" --connect-expired-password
    new_password=$MPWD
    mysql -h $MH -u $MU --password="$temp_password" -e "ALTER USER $MU@'localhost' IDENTIFIED BY '$new_password'"
    echo "max_allowed_packet=999999999" >>/etc/my.cnf
    echo "sql-mode=STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION" >>/etc/my.cnf
    echo "restart mysql"
    sudo $SYSTEMCTL restart mysqld
    #mysql -u root --password='K0gni!@#' -e "SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));"
    echo "create kogni app"
    mysql -h $MH -u $MU --password=$new_password -e "create database kogni_app"
    sudo $SYSTEMCTL stop mysqld
    echo '============Mysql installed============'
    method_break
}


install_mysql