#!/usr/bin/env bash
set -e

while [[ "$#" -gt 0 ]]; do
    case $1 in
        -kh|--kogni-home) KH="$2"; shift ;;
        -d|--docker) FOR_DOCKER=1 ;;
        -mh| --mysql-host) MH="$2"; shift;;
        -mu| --mysql-username) MU="$2"; shift;;
        -mpwd| --mysql-password) MPWD="$2"; shift;;
        -h|--help) printf "### Kogni Startup Script ###\n\nPass '-kh' or '--kogni-home' which should be same as what you have selected for installing Kogni \n\nAdd flag '-d' or '--docker' if you are running this script inside a container\n\nExample: './start_kogni.sh -kh /opt/kogni'\n\nExample: './start_kogni.sh -kh /opt/kogni -d\n"; exit 0 ;;
        *) echo "Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done

if [ -z ${KH+x} ];
  then
    printf "Kogni Home (-kh or --kogni-home) should be passed\n\nuse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MH+x} ];
  then
    printf "Mysql host (-mh or --mysql-host) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MU+x} ];
  then
    printf "Mysql username (-mu or --shared-access-signature) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MPWD+x} ];
  then
    printf "Mysql password (-mpwd or --mysql-password) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ "$FOR_DOCKER" = 1 ];
  then
    SYSTEMCTL=systemctl.py
  else
    SYSTEMCTL=systemctl
fi

export KOGNI_HOME=$KH
export SPARK_HOME=$KOGNI_HOME/spark/spark-2.4.6-bin-without-hadoop
echo "export KOGNI_HOME=$KH" >>~/.bashrc
source ~/.bashrc
cd $KOGNI_HOME
kogni_dump_done=false


function check_kogni_dump_done() {
  db_exists=$(mysql -h $MH -u $MU -p$MPWD -e "show databases like 'kogni_demo_data'" | sed -n '2p')
  if [[ "$db_exists" = 'kogni_demo_data' ]]; then
      kogni_dump_done=true
  fi
}

function dump_data() {
    mysql -h $MH -u $MU -p$MPWD -e "create database kogni_demo_data"
    mysql -h $MH -u $MU -p$MPWD -e "create database company"
    mysql -h $MH -u $MU -p$MPWD kogni_demo_data <$KOGNI_HOME/kogni_dem_data_1.sql
    mysql -h $MH -u $MU -p$MPWD company <$KOGNI_HOME/company_db.sql
    # not adding dummy data
#    mysql -u root --password='K0gni!@#' kogni_app <$KOGNI_HOME/kogni_demo.sql
    # select enabled classifiers
     mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.kogni_classifier set enabled = 1, scan_free_form_text = 1 where id in (1,3,4,5,6,11,12,13,18,22,113);"
     # disable all other classifiers
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.kogni_classifier set enabled = 0 where id not in (1,3,4,5,6,11,12,13,18,22,113);"
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.app_properties set pvalue  = 'true' where name = 'use.new.dashboard.job';"
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.app_properties set pvalue  = 'local[1]' where name = 'kmask.master';"
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.app_properties set pvalue  = 'maskInspector' where name = 'airflow.kmask.spark.dagid';"
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.app_properties set pvalue  = 'http://kogni-image-classifier:5000/ocr' where name = 'kogni.image.inspection.ocr.url';"
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.app_properties set pvalue  = 'http://kogni-image-classifier:5000/upload' where name = 'kogni.image.inspection.url';"
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.app_properties set pvalue  = 'true' where name = 'auto.run.dashboardjob';"
    mysql -h $MH -u $MU -p$MPWD -e "update kogni_app.app_properties set pvalue  = 'true' where name = 'enable.vault.save';"
    mysql -h $MH -u $MU -p$MPWD -e "use kogni_app;update app_properties set pvalue='kogni_app' where name='metadata.database';update app_properties set pvalue='K0gni!@#' where name='metadata.password'"
    curl --insecure https://localhost:8080/api/app/refreshProperties
}


function start_kogni(){
    echo "===============Starting Kogni app=================="
    if [ "$FOR_DOCKER" = 1 ];
      then
        export KARIBA_HOME=$KOGNI_HOME/kariba
        nohup /usr/bin/java -Xmx1g -jar -Dspring.profiles.active=demo -Dspring.config.location=$KARIBA_HOME/properties/ -Dlogging.file=$KARIBA_HOME/logs/kogni.log $(ls $KARIBA_HOME/kogni*.war) -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=$KARIBA_HOME/ >> /dev/null &
      else
        sudo $SYSTEMCTL start kogni
    fi
    echo "Waiting for Kogni App to start"
    while true; do
        if [ "$(curl --silent --insecure --max-time 2 -I https://localhost:8080/api/kogni/version/ | sed 's/^[^ ]*  *\([0-9]\).*/\1/; 1q')" = 4 ]; then
            break
        else
            sleep 10
        fi
    done
    echo "Kogni App started!"
    echo "===============Kogni app started=================="
}



function start_airflow(){
    echo "===============Starting Airflow=================="
    export AIRFLOW_HOME=$KOGNI_HOME/airflow
    source $AIRFLOW_HOME/env/bin/activate
    curl --insecure https://localhost:8080/api/app/refreshProperties
    nohup airflow initdb >> /dev/null &
    nohup airflow webserver -p 9090 >>/dev/null &
    nohup airflow scheduler >>/dev/null &
    sleep 50
    airflow unpause sparkInspector
    deactivate
    echo "===============Airflow started=================="
}


function start_spark(){
    echo "===============Starting Spark=================="
    sh $SPARK_HOME/sbin/start-master.sh --webui-port 8081
    export SPARK_MASTER_HOST="$(hostname -f)"
    sh $SPARK_HOME/sbin/start-slave.sh spark://$SPARK_MASTER_HOST:7077 -c 100
    sleep 10
    echo "===============Spark started=================="
}

function start_flask(){
    echo "===============Starting flask=================="
    cd $KOGNI_HOME/kogni_document_classifier/code
    nohup gunicorn --bind 0.0.0.0:5000 --workers=2 --max-requests 40 --max-requests-jitter 20  --error-logfile $KOGNI_HOME/kogni_document_classifier/error.log --access-logfile $KOGNI_HOME/kogni_document_classifier/access.log --capture-output --log-level debug kogni_main:app > $KOGNI_HOME/kogni_document_classifier/image.log &
    sleep 20
    echo "===============Flask started=================="
}

function start_grafana() {
  echo "===============Starting Grafana=================="
  sudo service grafana-server start
}

function start_telegraf() {
  sudo $SYSTEMCTL start telegraf
}

function start_elasticsearch() {
  if [ "$FOR_DOCKER" = 1 ];
    then
      runuser -l elastic -c 'export JAVA_HOME=/usr/java/jdk1.8.0_212-amd64;nohup /elasticsearch-7.6.2/bin/elasticsearch &';
    else
      systemctl start elasticsearch
  fi
}

function start_influx_db() {
  sudo nohup influxd &
}

function method_break() {
    echo "================================================="
    echo ""
    echo ""
    sleep 3
    echo "================================================="
}

function start_nmap() {
    sh  $KOGNI_HOME/NMap/startup.sh
}

echo "==============Starting Application================"
check_kogni_dump_done
start_kogni
start_spark
start_flask
if [ "$kogni_dump_done" = false ]; then
      dump_data
fi
start_airflow
start_nmap
start_elasticsearch
#start_grafana
#start_telegraf
#start_influx_db
echo "==============Application started================="
