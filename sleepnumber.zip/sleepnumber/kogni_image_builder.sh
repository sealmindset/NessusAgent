#!/usr/bin/env bash
set -e

while [[ "$#" -gt 0 ]]; do
    case $1 in
        -kh|--kogni-home) KH="$2"; shift ;;
        -sas|--shared-access-signature) SAS="$2"; shift ;;
        -mh| --mysql-host) MH="$2"; shift;;
        -mu| --mysql-username) MU="$2"; shift;;
        -mpwd| --mysql-password) MPWD="$2"; shift;;
        -d|--docker) FOR_DOCKER=1 ;;
        -h|--help) printf "### Kogni Installation Script ###\n\nPass '-kh' or '--kogni-home' for choosing Kogni installation folder \n\nAdd flag '-d' or '--docker' if you are running this script inside a container\n\nPass '-sas' or '-shared-access-signature' that is used to download artifacts, Reach out to Kogni team if you do not have this\n\nExample: './kogni_image_builder.sh -kh /opt/kogni -sas 'SAS TOKEN''\n\nExample: './kogni_image_builder.sh -kh /opt/kogni -sas 'SAS TOKEN' -d\n"; exit 0 ;;
        *) echo "Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done

if [ -z ${KH+x} ];
  then
    printf "Kogni Home (-kh or --kogni-home) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${SAS+x} ];
  then
    printf "Shared Access Signature (-sas or --shared-access-signature) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MH+x} ];
  then
    printf "Mysql host (-mh or --mysql-host) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MU+x} ];
  then
    printf "Mysql username (-mu or --shared-access-signature) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ -z ${MPWD+x} ];
  then
    printf "Mysql password (-mpwd or --mysql-password) should be passed\n\nUse --help to look at arguments\n\nExiting!\n"
    exit 1
fi

if [ "$FOR_DOCKER" = 1 ];
  then
    SYSTEMCTL=systemctl.py;
  else
    SYSTEMCTL=systemctl;
fi

connection=false

echo "==========Starting Kogni Installation============="
echo "creating kogni user"
id -u kogni &>/dev/null || sudo adduser kogni
echo "Kogni user created"
export KOGNI_HOME=$KH
echo "export KOGNI_HOME=$KH" >>~/.bashrc
source ~/.bashrc
export KOGNI_ARTIFACT_HOME=$KOGNI_HOME/kogni-artifacts
echo "export KOGNI_ARTIFACT_HOME=$KOGNI_HOME/kogni-artifacts" >>~/.bashrc
source ~/.bashrc
mkdir -p $KOGNI_ARTIFACT_HOME
cd $KOGNI_HOME

validate_mysql_connection(){
 echo "Mysql Validation Started"
 sudo $SYSTEMCTL start mysqld
 db_exists=$(mysql -h $MH -u $MU --password=$MPWD -e "show databases like 'kogni_app'" | sed -n '2p')
 if [[ "$db_exists" = 'kogni_app' ]];
 then
     connection=true
     echo "database kogni_app already present"
 else
    created=$(mysql -h $MH -u $MU --password=$MPWD -e "create database kogni_app; show databases like 'kogni_app'" | sed -n '2p')
    if [[ "$created" = 'kogni_app' ]];
      then
        connection=true
        echo "database kogni_app created"
      else
        connection=false
        echo "failed to create database kogni_app"
    fi
 fi
}

function install_azurecli() {
  echo "============Installing Azure CLI============"
  cd /
  wget https://packages.microsoft.com/yumrepos/azure-cli/azure-cli-2.9.1-1.el7.x86_64.rpm
  sudo yum localinstall azure-cli-2.9.1-1.el7.x86_64.rpm -y
  rm -rf azure-cli-2.9.1-1.el7.x86_64.rpm
  az --version
  echo "============Azure CLI Installation complete============"
  method_break
}


function download_artifacts() {
  echo "============Downloading Artifacts required for installation============"
  cd $KOGNI_ARTIFACT_HOME
  az storage blob download-batch -d . --pattern * -s kogni-artifacts --account-name kogniblobstoragetest --sas-token $SAS
  echo "============Downloading artifacts completed============"
  method_break
}


function install_prerequisites() {
    echo "============Installing Kogni Prerequisites============"
    yum install sudo -y
    yum install wget -y
    yum install bzip2 -y
    yum install which -y
    yum install mesa-libGL-devel -y
    echo "============Prerequisites Kogni Installed============"
    method_break
}

function install_java() {
    echo '============Installing Java============'
    cd $KOGNI_HOME
    mv $KOGNI_ARTIFACT_HOME/jdk-8u212-linux-x64.rpm .
    sudo yum localinstall jdk-8u212-linux-x64.rpm -y
    echo "export JAVA_HOME=/usr/java/jdk1.8.0_212-amd64" >>~/.bashrc
    echo "export PATH=\$JAVA_HOME/bin:\$PATH" >>~/.bashrc
    source ~/.bashrc
    java -version
    rm -f jdk-8u212-linux-x64.rpm
    echo '============Java Installed============'
    method_break
}

function install_python() {
    echo '============Installing Python============'
    echo 'downloading anaconda'
    wget https://repo.anaconda.com/archive/Anaconda3-2019.03-Linux-x86_64.sh -O Anaconda3-2019.03-Linux-x86_64.sh
    echo 'installing anaconda'
    sh Anaconda3-2019.03-Linux-x86_64.sh -b -u -p $KOGNI_HOME/anaconda3
    $KOGNI_HOME/anaconda3/bin/conda init
    source ~/.bashrc
    rm -f Anaconda3-2019.03-Linux-x86_64.sh
    echo '============Python Installed============'
    method_break
}

function install_pip() {
    echo '============Installing Pip============'
    cd $KOGNI_HOME
    wget https://bootstrap.pypa.io/get-pip.py -O get-pip.py
    python3 get-pip.py
    rm -f get-pip.py
    echo '============Pip Installed============'
    method_break
}

function install_airflow() {
    echo "============Installing Airflow============"
    #changing db name in property metabase.database.
    #mysql -u root --password='K0gni!@#' -e "use kogni_app;update app_properties set pvalue='kogni_app' where name='metadata.database';update app_properties set pvalue='K0gni!@#' where name='metadata.password'"
    #curl --insecure https://localhost:8080/api/app/refreshProperties
    export AIRFLOW_HOME=$KOGNI_HOME/airflow
    echo "export AIRFLOW_HOME=$KOGNI_HOME/airflow" >>~/.bashrc
    source ~/.bashrc
    python3 -m pip install --user virtualenv
    python3 -m venv $AIRFLOW_HOME/env
    source $AIRFLOW_HOME/env/bin/activate
    cd $KOGNI_HOME
    pip3 install --upgrade pip
    dnf install mysql-devel gcc python2-devel python36-devel -y
    sudo dnf group install "Development Tools"
    pip3 install mysqlclient
    AIRFLOW_GPL_UNIDECODE=yes pip3 install apache-airflow==1.10.2
    export AIRFLOW__CORE__LOAD_EXAMPLES=False
    mkdir -p $AIRFLOW_HOME
    cd $AIRFLOW_HOME
    mv $KOGNI_ARTIFACT_HOME/dags.tar.gz .
    mv $KOGNI_ARTIFACT_HOME/plugins.tar.gz .
    pip3 install tenacity==5.0.2
    tar -xvf dags.tar.gz
    tar -xvf plugins.tar.gz
    airflow initdb
    sed -i "s/load_examples = True/load_examples = False/g" airflow.cfg
    sed -i "s/dags_are_paused_at_creation = True/dags_are_paused_at_creation = False/g" airflow.cfg
    sed -i "s^@@kogni-home@@^$KOGNI_HOME^g" $AIRFLOW_HOME/dags/sparkInspector.py
    sed -i "s^@@mysql-host@@^$MH^g" $AIRFLOW_HOME/dags/mask_inspector.py
    sed -i "s^@@mysql-username@@^$MU^g" $AIRFLOW_HOME/dags/mask_inspector.py
    sed -i "s^@@mysql-password@@^$MPWD^g" $AIRFLOW_HOME/dags/mask_inspector.py
    rm -f dags.tar.gz
    rm -f plugins.tar.gz
    deactivate
    echo '============Airflow installed============'
    method_break
}

function install_kogni_app() {
    echo "============Installing Kogni App============"
    cd $KOGNI_HOME
    export KARIBA_HOME=$KOGNI_HOME/kariba
    mkdir $KARIBA_HOME
    cd $KARIBA_HOME
    mv $KOGNI_ARTIFACT_HOME/kogni-3.1.war .
    mkdir properties
    mv $KOGNI_ARTIFACT_HOME/application-demo.yml properties/
    mv $KOGNI_ARTIFACT_HOME/certificate.p12 $KARIBA_HOME/
    sed -i "s^@@kariba-home@@^$KARIBA_HOME^g" properties/application-demo.yml
    sed -i "s^@@mysql-host@@^$MH^g" properties/application-demo.yml
    sed -i "s^@@mysql-username@@^$MU^g" properties/application-demo.yml
    sed -i "s^@@mysql-password@@^$MPWD^g" properties/application-demo.yml
    mkdir logs
    mkdir passwords
    chown kogni -R logs
    chown kogni -R passwords
    sed -i "s^@@kariba-home@@^$KARIBA_HOME^g" $KOGNI_ARTIFACT_HOME/kogni.service
    mv $KOGNI_ARTIFACT_HOME/kogni.service /usr/lib/systemd/system/kogni.service
    cp /usr/lib/systemd/system/kogni.service /etc/systemd/system/
    ln -s /usr/lib/systemd/system/kogni.service /etc/systemd/system/multi-user.target.wants/kogni.service
    sudo $SYSTEMCTL daemon-reload
    mv $KOGNI_ARTIFACT_HOME/kogni-external-dependencies .
    echo "============Kogni App Installed============"
    method_break
}


function install_spark() {
    echo "============Installing Hadoop and Spark============"
    cd $KOGNI_HOME
    echo "export HADOOP_VERSION=2.8.5" >>~/.bashrc
    echo "Hadoop version set done...."
    echo "export HADOOP_HOME=\$KOGNI_HOME/hadoop/hadoop-2.8.5" >>~/.bashrc
    echo "Hadoop home set done...."
    echo "export HADOOP_CONF_DIR=\$HADOOP_HOME/etc/hadoop" >>~/.bashrc
    echo "Hadoop conf dir set done...."
    echo "export PATH=\$HADOOP_HOME/bin:\$PATH" >>~/.bashrc
    echo "Hadoop bin set done...."
    pwd
    mkdir hadoop
    echo "Hadoop directory created...."
    cd hadoop
    mv $KOGNI_ARTIFACT_HOME/hadoop-2.8.5.tar.gz .
    tar -xzf hadoop-2.8.5.tar.gz
    rm -rf hadoop-2.8.5.tar.gz
    rm -rf hadoop-2.8.5/share/doc
    echo "export SPARK_VERSION=2.4.6" >>~/.bashrc
    echo "export SPARK_PACKAGE=spark-\$SPARK_VERSION-bin-without-hadoop-scala-2.12" >>~/.bashrc
    echo "export SPARK_HOME=\$KOGNI_HOME/spark/spark-\$SPARK_VERSION-bin-without-hadoop-scala-2.12" >>~/.bashrc
    cd $KOGNI_HOME
    mkdir spark
    cd spark
    mv $KOGNI_ARTIFACT_HOME/spark-2.4.6-bin-without-hadoop-scala-2.12.tgz .
    tar -xvf spark-2.4.6-bin-without-hadoop-scala-2.12.tgz
    rm -rf spark-2.4.6-bin-without-hadoop-scala-2.12.tgz
    mv spark-2.4.6-bin-without-hadoop-scala-2.12/conf/spark-env.sh.template spark-2.4.6-bin-without-hadoop-scala-2.12/conf/spark-env.sh
    echo "export JAVA_HOME=/usr/java/jdk1.8.0_212-amd64" >> spark-2.4.6-bin-without-hadoop-scala-2.12/conf/spark-env.sh
    echo "export SPARK_DIST_CLASSPATH=\$(hadoop classpath)" >> spark-2.4.6-bin-without-hadoop-scala-2.12/conf/spark-env.sh
    echo "export PATH=\$SPARK_HOME/bin:\$PATH" >>~/.bashrc
    source ~/.bashrc
    mv $KOGNI_ARTIFACT_HOME/application.properties .
    mv $KOGNI_ARTIFACT_HOME/spark_inspector_project_shaded.jar .
    mv $KOGNI_ARTIFACT_HOME/masking-lib-3.1.jar .
    mv $KOGNI_ARTIFACT_HOME/kogni-spark-external-dependencies $KOGNI_HOME
    sed -i "s^@@mysql-host@@^$MH^g" application.properties
    sed -i "s^@@mysql-username@@^$MU^g" application.properties
    sed -i "s^@@mysql-password@@^$MPWD^g" application.properties
    rm -rf $KOGNI_HOME/hadoop/hadoop-2.8.5/share/hadoop/common/lib/json-smart-1.3.1.jar
    echo "============Hadoop and Spark Installed============"
    method_break
}


function install_flask_image_classifier() {
    echo "============Installing Image classifier============"
    cd $KOGNI_HOME
    mv $KOGNI_ARTIFACT_HOME/kogni_document_classifier.tar.gz .
    tar -xvf kogni_document_classifier.tar.gz
    pip3 install opencv-python
    pip3 install opencv-contrib-python
    pip3 install regex
    pip3 install PyMuPDF
    pip3 install python-Levenshtein
    pip3 install fuzzywuzzy
    pip3 install flask
    pip3 install gunicorn
    pip3 install spacy
    pip3 install absl-py
    pip3 install tensorflow==1.15.0 --ignore-installed
    pip3 install ipykernel
    pip3 install tensorflow_hub
    pip3 install pandas
    python3 -m spacy download en_core_web_sm
    yum-config-manager --add-repo https://download.opensuse.org/repositories/home:/Alexander_Pozdnyakov/CentOS_7/
    sudo rpm --import https://build.opensuse.org/projects/home:Alexander_Pozdnyakov/public_key
    yum update -y
    wget https://rpmfind.net/linux/centos/7.9.2009/os/x86_64/Packages/libwebp-0.3.0-7.el7.x86_64.rpm
    sudo yum localinstall libwebp-0.3.0-7.el7.x86_64.rpm --skip-broken
    dnf install leptonica -y --skip-broken
    dnf install tesseract -y --nobest --skip-broken
    yum install tesseract-langpack-deu -y --nobest --skip-broken
    yum install libXext libSM libXrender -y --nobest
    mv $KOGNI_ARTIFACT_HOME/mupdf-1.18.0-source.tar.xz .
    tar -xJf mupdf-1.18.0-source.tar.xz
    cd mupdf-1.18.0-source
    export CFLAGS="-fPIC"
    make CC=c99 HAVE_X11=no HAVE_GLFW=no HAVE_GLUT=no prefix=/usr/local
    make CC=c99 HAVE_X11=no HAVE_GLFW=no HAVE_GLUT=no prefix=/usr/local install
    cd ..
#    mkdir $KOGNI_HOME/kogni_document_classifier/tmp
    sed -i "s^/home/kogni^$KOGNI_HOME^g" $KOGNI_HOME/kogni_document_classifier/code/installation_location.py
    rm -f kogni_document_classifier.tar.gz
    echo "============Image classifier Installed============"
    method_break
}

function add_startup_data() {
    echo "============Dumping data into Kogni database============"
    cd $KOGNI_HOME
    mv $KOGNI_ARTIFACT_HOME/one_profile.sql .
    mv $KOGNI_ARTIFACT_HOME/kogni_dem_data_1.sql .
    mv $KOGNI_ARTIFACT_HOME/company_db.sql .
    mv $KOGNI_ARTIFACT_HOME/kogni_demo.sql .
    mv $KOGNI_ARTIFACT_HOME/AllTypeFiles .
    echo "============Dumping completed============"
    method_break
}

function install_nmap() {
    echo "============Installing Nmap============"
    mv $KOGNI_ARTIFACT_HOME/NMap/ $KOGNI_HOME/NMap
    rpm -vhU $KOGNI_HOME/NMap/nmap-7.80-1.x86_64.rpm
    echo '============Nmap installed============'
    method_break
}

function install_grafana() {
  cd $KOGNI_HOME
  mv $KOGNI_ARTIFACT_HOME/grafana-6.3.6-1.x86_64.rpm .
  sudo yum localinstall grafana-6.3.6-1.x86_64.rpm -y
  rm -rf grafana-6.3.6-1.x86_64.rpm
}

function install_influxdb() {
  cd $KOGNI_HOME
  mv $KOGNI_ARTIFACT_HOME/influxdb-1.7.8.x86_64.rpm .
  sudo yum localinstall influxdb-1.7.8.x86_64.rpm -y
  rm -rf influxdb-1.7.8.x86_64.rpm
  rm -rf /etc/influxdb/influxdb.conf
  mv $KOGNI_ARTIFACT_HOME/influxdb.conf /etc/influxdb/influxdb.conf
  mkdir $KOGNI_HOME/influxdb
  chmod -R 777 $KOGNI_HOME/influxdb
  sudo influxd > $KOGNI_HOME/influxdb/influxdb.log &
  echo $! > $KOGNI_HOME/influxd.pid
}

function install_telegraph() {
  cd $KOGNI_HOME
  mv $KOGNI_ARTIFACT_HOME/telegraf-1.12.2-1.x86_64.rpm .
  sudo yum localinstall telegraf-1.12.2-1.x86_64.rpm -y
  rm -rf telegraf-1.12.2-1.x86_64.rpm
  rm -rf /etc/telegraf/telegraf.conf
  mv $KOGNI_ARTIFACT_HOME/telegraf.conf /etc/telegraf/telegraf.conf
  sudo $SYSTEMCTL daemon-reload
}


function install_elasticsearch() {
    echo '============Installing Elasticsearch============'
    if [ "$FOR_DOCKER" = 1 ];
      then
        cd /
        adduser elastic
        wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-7.6.2-darwin-x86_64.tar.gz
        tar -xzf elasticsearch-7.6.2-darwin-x86_64.tar.gz
        sudo chmod -R 777 elasticsearch-7.6.2
        rm -rf elasticsearch-7.6.2-darwin-x86_64.tar.gz
        echo "xpack.security.enabled: false" >>/elasticsearch-7.6.2/config/elasticsearch.yml
        echo "xpack.graph.enabled: false" >>/elasticsearch-7.6.2/config/elasticsearch.yml
        echo "xpack.ml.enabled: false" >>/elasticsearch-7.6.2/config/elasticsearch.yml
        echo "xpack.watcher.enabled: false" >>/elasticsearch-7.6.2/config/elasticsearch.yml
        cd $KOGNI_HOME
      else
        cd $KOGNI_HOME
        mkdir elasticsearch
        cd elasticsearch
        mv $KOGNI_ARTIFACT_HOME/elasticsearch-7.6.2-x86_64.rpm .
        sudo yum localinstall elasticsearch-7.6.2-x86_64.rpm -y
        rm -rf elasticsearch-7.6.2-x86_64.rpm
        sudo $SYSTEMCTL daemon-reload
    fi
  echo '============Done Elasticsearch============'
}

function install_kmask() {
  echo '============Installing Kmask============'
  cd $KOGNI_HOME
  mkdir kmask
  cd kmask
  mv $KOGNI_ARTIFACT_HOME/kogni-masking-external-dependencies .
  mv $KOGNI_ARTIFACT_HOME/Database-Masking-3.1-jar-with-dependencies.jar .
  mv $KOGNI_ARTIFACT_HOME/kmask.sh .
  sed -i "s^@@kogni-home@@^$KOGNI_HOME^g" $KOGNI_HOME/kmask/kmask.sh
  sudo ln -s $KOGNI_HOME/kmask/kmask.sh /usr/local/bin/kmask
  chmod +x $KOGNI_HOME/kmask/kmask.sh
  echo '============Kmask installed============'
}

function method_break() {
    echo "================================================="
    echo ""
    echo ""
    sleep 3
    echo "================================================="
}

install_prerequisites
install_python
install_pip
install_azurecli
download_artifacts
install_elasticsearch
install_java
validate_mysql_connection
if [[ $connection = 'true' ]];
then
  install_kogni_app
  install_spark
  install_airflow
  install_flask_image_classifier
 # install_nmap
  #install_grafana
  install_kmask
  add_startup_data
  rm -rf $KOGNI_ARTIFACT_HOME
  echo 'Kogni Installation Done!'
else
  echo 'Kogni installation aborted as mysql is not installed'
fi

exit

//TODO : delete this file once image build is done.